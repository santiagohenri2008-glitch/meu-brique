# Meu Brique — projeto Android

Aplicativo pessoal de compra e revenda, com interface escura, dados locais e funcionamento offline.

## Recursos
- Registrar compra com nome, custo, preço de venda previsto, quantidade, data e observação.
- Registrar venda com o preço real recebido e data.
- Lucro bruto por item e visão geral do faturamento.
- Estoque, busca e filtro de produtos.
- Backup/restauração em JSON e exportação CSV.
- Dados armazenados localmente no WebView (`localStorage`); não há servidor nem conta.

## Como gerar o APK
Este ambiente de entrega não contém Android SDK/Gradle, então o APK compilado não pôde ser gerado aqui. O projeto-fonte está preparado para abrir no Android Studio.

1. Instale o Android Studio em um computador e abra a pasta `MeuBrique`.
2. Aguarde o Gradle sincronizar e instale o Android SDK Platform 35, se solicitado.
3. Selecione **Build > Build APK(s)**.
4. O APK de debug ficará em `app/build/outputs/apk/debug/app-debug.apk`.
5. Transfira esse APK para seu Android e permita a instalação de apps dessa origem.

## Atenção aos dados
Os registros ficam no armazenamento local do aplicativo. Desinstalar/limpar os dados do app pode apagar os registros; exporte um backup JSON regularmente. O CSV serve para abrir os dados em planilhas.

## Limitação da versão 1.0
O registro da venda usa uma caixa de diálogo simples para informar preço e data. Os valores de lucro são brutos e não descontam frete, taxas ou outros custos adicionais.
